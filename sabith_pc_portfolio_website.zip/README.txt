SABITH PC — PERSONAL PORTFOLIO WEBSITE

Files:
- index.html: complete responsive portfolio website.

How to view:
1. Extract the ZIP file.
2. Open index.html in Chrome or another web browser.

How to publish:
Upload index.html to your web hosting public_html folder (or upload the extracted folder contents to a hosting service).

Notes:
- The content is based on the CV provided in this conversation.
- The work section describes areas of experience, not claimed client projects or measured campaign results.
- Add real screenshots, project URLs and campaign results when you are ready.
